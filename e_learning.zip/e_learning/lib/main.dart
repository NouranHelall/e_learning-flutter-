import 'package:device_preview/device_preview.dart';
import 'package:e_learning/core/app_route/app_route.dart';
import 'package:e_learning/core/di/service_locator.dart';
import 'package:flutter/material.dart';
import 'core/services/firebase_service.dart';
import 'features/splash/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await FirebaseService.init();
  await setupGetIt();

  runApp(
    DevicePreview(
      enabled: true,
      builder: (context) => MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  AppRoute appRoute = AppRoute();

  MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      onGenerateRoute: appRoute.generateRoute,
    );
  }
}