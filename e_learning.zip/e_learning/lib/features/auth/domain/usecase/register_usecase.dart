import 'package:e_learning/core/networking/api_result.dart';

import '../../../register/data/models/register_request_model.dart';
import '../../data/repo/auth_repo.dart';


class RegisterUsecase {
  final AuthRepo _authRepo;
  RegisterUsecase(this._authRepo);

  Future<ApiResult<String>> call(RegisterRequestModel model) {
    return _authRepo.register(model);
  }
}