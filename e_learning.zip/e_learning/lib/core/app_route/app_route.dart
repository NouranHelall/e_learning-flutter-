import 'package:e_learning/features/home/presentation/ui/home_screen.dart';
import 'package:e_learning/features/splash/splash_screen.dart';
import 'package:flutter/material.dart';

import '../../features/login/presentation/ui/login_screen.dart';
import '../../features/register/presentation/ui/register_screen.dart';

class AppRoute {
  Route? generateRoute(RouteSettings routesettings) {
    switch (routesettings.name) {
      case "/":
        return MaterialPageRoute(builder: (context) => SplashScreen());

      case "/login":
        return MaterialPageRoute(builder: (context) => LoginScreen());

      case "/register":
        return MaterialPageRoute(builder: (context) => RegisterScreen());

      case "/home":
        return MaterialPageRoute(builder: (context) => HomeScreen());

      default:
        return null;
    }
  }
}