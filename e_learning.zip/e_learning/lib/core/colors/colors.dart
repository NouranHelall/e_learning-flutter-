import 'package:flutter/material.dart';

class MyColors {
  Color button = const Color(0xFF1B2CC1);
  Color primary = const Color(0xFF4E5CF6);
  Color background = const Color(0xFFF7F8FC);
  Color textPrimary = const Color(0xFF1D1E2C);
  Color textSecondary = const Color(0xFF9096B2);
  Color card = const Color(0xFFF1F2F6);
}